package com.blogpessoal.Turma34;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Turma34Application {

	public static void main(String[] args) {
		SpringApplication.run(Turma34Application.class, args);
	}

}
